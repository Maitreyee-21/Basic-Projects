<?php
$conn = mysqli_connect("localhost","root","","grievance_db");
if (!$conn) die("DB Error");
?>
